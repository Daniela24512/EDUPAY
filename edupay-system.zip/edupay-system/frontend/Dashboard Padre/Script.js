// Script.js - Dashboard Padre (integrado con botón fijo en HTML)

document.addEventListener("DOMContentLoaded", async () => {
    const usuario = JSON.parse(localStorage.getItem("user"));
    const usernameDisplay = document.getElementById("username");
    const topbarLogoutBtn = document.getElementById("topbar-logout-btn");
    const tablaPendientes = document.getElementById("tablaPendientes");
    const tablaServicios = document.getElementById("tabla-servicios")?.querySelector("tbody");
    const totalElemento = document.getElementById("totalpago");
    const tablaHistorial = document.getElementById("tablaHistorial");
    const btnPagar = document.getElementById("btnSubirBoucher");
    const inputBoucher = document.createElement("input");
    inputBoucher.type = "file";
    inputBoucher.accept = "image/*";

    let total = 0;
    let pagosSeleccionados = [];

    if (usernameDisplay) {
        usernameDisplay.textContent = usuario.nombre;
    }

    if (topbarLogoutBtn) {
        topbarLogoutBtn.addEventListener("click", () => {
            if (confirm("¿Seguro que deseas cerrar sesión?")) {
                localStorage.removeItem("user");
                window.location.href = "../Login/index.html";
            }
        });
    }

    // Historial
    if (tablaHistorial) {
        try {
            const res = await fetch(`http://localhost:3000/api/historial/${usuario.correo}`);
            const data = await res.json();

            if (data.length === 0) {
                tablaHistorial.innerHTML = <tr><td colspan="4">No hay pagos aprobados.</td></tr>;
                return;
            }

            data.forEach(pago => {
                const fila = document.createElement("tr");
                fila.innerHTML = `
                    <td>${pago.estudiante}</td>
                    <td>$${parseFloat(pago.monto).toFixed(2)}</td>
                    <td>${new Date(pago.fechaPago).toLocaleDateString()}</td>
                    <td>${pago.metodoPago}</td>
                `;
                tablaHistorial.appendChild(fila);
            });
        } catch (err) {
            console.error("❌ Error al cargar historial:", err);
            alert("Error al cargar historial de pagos.");
        }
    }

    // Pagos pendientes
    if (tablaPendientes) {
        try {
            const res = await fetch(`http://localhost:3000/api/pendientes/${usuario.correo}`);
            const data = await res.json();

            if (data.length === 0) {
                tablaPendientes.innerHTML = "<tr><td colspan='7'>No hay pagos pendientes.</td></tr>";
                return;
            }

            tablaPendientes.innerHTML = "";
            data.forEach(p => {
                const fila = document.createElement("tr");
                fila.innerHTML = `
                    <td><input type="checkbox" class="pago-checkbox" data-descripcion="${p.descripcion}" data-estudiante="${p.estudiante}" data-curso="${p.curso}" data-monto="${p.monto}"></td>
                    <td>${p.descripcion}</td>
                    <td>${p.periodo}</td>
                    <td>${new Date(p.fechaVencimiento).toLocaleDateString()}</td>
                    <td>${p.estudiante}</td>
                    <td>${p.curso}</td>
                    <td>$${p.monto.toFixed(2)}</td>
                `;
                tablaPendientes.appendChild(fila);
            });
        } catch (err) {
            console.error("❌ Error al cargar pagos pendientes:", err);
            alert("Error al cargar pagos.");
        }
    }

    // Selección de pagos
    document.addEventListener("change", (e) => {
        if (e.target.classList.contains("pago-checkbox")) {
            const checkbox = e.target;
            const { descripcion, estudiante, curso, monto } = checkbox.dataset;
            const montoFloat = parseFloat(monto);

            if (checkbox.checked) {
                const fila = document.createElement("tr");
                fila.innerHTML = `
                    <td>${descripcion}</td>
                    <td>${estudiante}</td>
                    <td>${curso}</td>
                    <td>$${montoFloat.toFixed(2)}</td>
                `;
                tablaServicios.appendChild(fila);
                pagosSeleccionados.push({ descripcion, estudiante, curso, monto: montoFloat });
                total += montoFloat;
            } else {
                for (let i = 0; i < tablaServicios.rows.length; i++) {
                    if (tablaServicios.rows[i].cells[0].textContent === descripcion) {
                        total -= parseFloat(tablaServicios.rows[i].cells[3].textContent.replace("$", ""));
                        tablaServicios.deleteRow(i);
                        break;
                    }
                }
                pagosSeleccionados = pagosSeleccionados.filter(p => p.descripcion !== descripcion);
            }

            totalElemento.textContent = $$;{total.toFixed(2)};
        }
    });

    // Subida de boucher y envío
    if (btnPagar) {
        btnPagar.addEventListener("click", async () => {
            if (pagosSeleccionados.length === 0) {
                alert("Selecciona al menos un pago.");
                return;
            }

            inputBoucher.click();

            inputBoucher.onchange = async () => {
                const file = inputBoucher.files[0];
                if (!file) return;

                const reader = new FileReader();
                reader.onload = async function (event) {
                    const boucherBase64 = event.target.result;

                    for (let pago of pagosSeleccionados) {
                        const payload = {
                            estudiante: pago.estudiante,
                            padre: usuario.correo,
                            fecha: new Date().toISOString(),
                            monto: pago.monto,
                            boucherBase64
                        };

                        try {
                            const res = await fetch("http://localhost:3000/api/pagos/transferencia", {
                                method: "POST",
                                headers: { "Content-Type": "application/json" },
                                body: JSON.stringify(payload)
                            });

                            if (!res.ok) throw new Error("Error al enviar pago");
                        } catch (err) {
                            console.error("❌ Error enviando pago:", err);
                            alert("Error al enviar el pago. Inténtalo de nuevo.");
                            return;
                        }
                    }

                    alert("✅ Pago enviado correctamente. En espera de aprobación.");
                    location.reload();
                };

                reader.readAsDataURL(file);
            };
        });
    }
    async function cargarProgresoPagos() {
        try {
            const res = await fetch(`http://localhost:3000/api/pagos/padre/${usuario.correo}`);
            const pagos = await res.json();
    
            const total = pagos.length;
            const aprobados = pagos.filter(p => p.estado === "aprobado").length;
            const pendientes = total - aprobados;
    
            const ctx = document.getElementById('progresoPagos')?.getContext('2d');
            if (ctx) {
                new Chart(ctx, {
                    type: 'doughnut',
                    data: {
                        labels: ['Aprobados', 'Pendientes'],
                        datasets: [{
                            data: [aprobados, pendientes],
                            backgroundColor: ['#28a745', '#ffc107']
                        }]
                    },
                    options: {
                        responsive: true,
                        plugins: {
                            legend: { position: 'bottom' }
                        }
                    }
                });
            }
        } catch (error) {
            console.error("Error al cargar progreso de pagos:", error);
        }
    }
    
    // Llama a la función si existe el canvas
    if (document.getElementById('progresoPagos')) {
        cargarProgresoPagos();
    }
});