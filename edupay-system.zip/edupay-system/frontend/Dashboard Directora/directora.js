// directora.js completo con creación de usuario padre y estudiantes vinculados

document.addEventListener('DOMContentLoaded', function () {
    const user = JSON.parse(localStorage.getItem("user"));
    if (user && user.nombre) {
        const usernameDisplay = document.getElementById("username");
        if (usernameDisplay) usernameDisplay.textContent = user.nombre;
    }

    const logoutButton = document.getElementById('topbar-logout-btn');
    if (logoutButton) {
        logoutButton.addEventListener('click', () => {
            localStorage.clear();
            window.location.href = "../Login/index.html";
        });
    }

    const btnBuscarPagos = document.getElementById('buscarPagos');
    const tablaPagos = document.getElementById('tablaPagos');

    async function buscarPagos() {
        const nombreEstudiante = document.getElementById('nombreEstudiante')?.value.toLowerCase();
        const fechaInicio = document.getElementById('fechaInicio')?.value;
        const fechaFin = document.getElementById('fechaFin')?.value;

        try {
            const res = await fetch('http://localhost:3000/api/pagos');
            const pagos = await res.json();

            const filtrados = pagos.filter(p => {
                const coincideNombre = !nombreEstudiante || p.estudiante.toLowerCase().includes(nombreEstudiante);
                const fechaPago = new Date(p.fecha).toISOString().split('T')[0];
                const coincideFecha = (!fechaInicio || fechaPago >= fechaInicio) && (!fechaFin || fechaPago <= fechaFin);
                return coincideNombre && coincideFecha;
            });

            tablaPagos.innerHTML = '';
            if (filtrados.length === 0) {
                tablaPagos.innerHTML = '<tr><td colspan="4">No se encontraron pagos.</td></tr>';
                return;
            }

            filtrados.forEach(pago => {
                const fila = document.createElement('tr');
                fila.innerHTML = `
                    <td>${pago.estudiante}</td>
                    <td>${pago.padre}</td>
                    <td>$${parseFloat(pago.monto).toFixed(2)}</td>
                    <td>${new Date(pago.fecha).toLocaleDateString()}</td>
                `;
                tablaPagos.appendChild(fila);
            });
        } catch (error) {
            console.error('Error al buscar pagos:', error);
            tablaPagos.innerHTML = '<tr><td colspan="4">Error al cargar los pagos.</td></tr>';
        }
    }

    if (btnBuscarPagos && tablaPagos) {
        btnBuscarPagos.addEventListener('click', buscarPagos);
        buscarPagos();
    }

    const formularioCrearUsuario = document.getElementById('formularioCrearUsuario');
    if (formularioCrearUsuario) {
        formularioCrearUsuario.addEventListener('submit', function (event) {
            event.preventDefault();

            const nombre = document.getElementById('nombreCompleto').value;
            const correo = document.getElementById('correoElectronico').value;
            const contrasena = document.getElementById('contrasena').value;
            const rol = document.getElementById('rol').value;

            fetch("http://localhost:3000/api/usuarios", {
                method: "POST",
                headers: { "Content-Type": "application/json" },
                body: JSON.stringify({ nombre, correo, contrasena, rol })
            })
            .then(async res => {
                if (!res.ok) throw new Error("Error al crear usuario");
                const data = await res.json();

                if (rol === "padre") {
                    const estudianteDivs = document.querySelectorAll('#listaEstudiantes > div');
                    for (const div of estudianteDivs) {
                        const nombre = div.querySelector('.nombreEstudiante')?.value;
                        const curso = div.querySelector('.cursoEstudiante')?.value;
                        const periodo = div.querySelector('.periodoEstudiante')?.value;

                        if (nombre && curso && periodo) {
                            await fetch("http://localhost:3000/api/estudiantes", {
                                method: "POST",
                                headers: { "Content-Type": "application/json" },
                                body: JSON.stringify({
                                    nombre,
                                    curso,
                                    periodo,
                                    correoPadre: correo
                                })
                            });
                        }
                    }
                }

                alert("✅ Usuario y estudiante(s) creados correctamente.");
                formularioCrearUsuario.reset();
                document.getElementById("contenedorEstudiantes").style.display = "none";
                document.getElementById("listaEstudiantes").innerHTML = "";
            })
            .catch(err => {
                console.error("Error al crear usuario:", err);
                alert("❌ Error al crear el usuario.");
            });
        });
    }

    const usuariosPorPagina = 5;
    let paginaActual = 1;
    let usuarios = [];

    async function cargarUsuariosDesdeAPI() {
        try {
            const res = await fetch('http://localhost:3000/api/usuarios/listar');
            usuarios = await res.json();
            mostrarUsuarios(paginaActual);
        } catch (error) {
            console.error('Error al cargar usuarios desde la API:', error);
        }
    }

    function mostrarUsuarios(pagina) {
        const tabla = document.getElementById('tablaUsuarios');
        if (!tabla) return;

        tabla.innerHTML = '';
        const busqueda = document.getElementById('busqueda')?.value.toLowerCase() || '';
        const filtroRol = document.getElementById('filtroRol')?.value || '';
        const filtroEstado = document.getElementById('filtroEstado')?.value || '';

        const filtrados = usuarios.filter(u => {
            const coincideBusqueda = u.nombre.toLowerCase().includes(busqueda) || u.correo.toLowerCase().includes(busqueda);
            const coincideRol = !filtroRol || u.rol === filtroRol;
            const coincideEstado = !filtroEstado || u.estado === filtroEstado;
            return coincideBusqueda && coincideRol && coincideEstado;
        });

        const inicio = (pagina - 1) * usuariosPorPagina;
        const paginados = filtrados.slice(inicio, inicio + usuariosPorPagina);

        paginados.forEach(u => {
            const fila = document.createElement('tr');
            fila.innerHTML = `
                <td>${u.nombre}</td>
                <td>${u.correo}</td>
                <td>${u.rol}</td>
                <td>${u.estado}</td>
            `;
            tabla.appendChild(fila);
        });

        mostrarPaginacion(filtrados.length, pagina);
    }

    function mostrarPaginacion(total, pagina) {
        const contenedor = document.getElementById('paginacion');
        if (!contenedor) return;

        contenedor.innerHTML = '';
        const totalPaginas = Math.ceil(total / usuariosPorPagina);

        for (let i = 1; i <= totalPaginas; i++) {
            const li = document.createElement('li');
            li.className = 'page-item' + (i === pagina ? ' active' : '');
            const a = document.createElement('a');
            a.href = '#';
            a.className = 'page-link';
            a.textContent = i;
            a.addEventListener('click', () => {
                paginaActual = i;
                mostrarUsuarios(paginaActual);
            });
            li.appendChild(a);
            contenedor.appendChild(li);
        }
    }

    if (document.getElementById('tablaUsuarios')) {
        cargarUsuariosDesdeAPI();
        document.getElementById('busqueda')?.addEventListener('input', () => mostrarUsuarios(paginaActual));
        document.getElementById('filtroRol')?.addEventListener('change', () => mostrarUsuarios(paginaActual));
        document.getElementById('filtroEstado')?.addEventListener('change', () => mostrarUsuarios(paginaActual));
    }
});