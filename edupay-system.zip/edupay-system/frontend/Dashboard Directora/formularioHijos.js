document.addEventListener("DOMContentLoaded", () => {
    const rolSelect = document.getElementById("rol");
    const contenedorEstudiantes = document.getElementById("contenedorEstudiantes");
    const listaEstudiantes = document.getElementById("listaEstudiantes");
    const btnAgregarEstudiante = document.getElementById("btnAgregarEstudiante");

    rolSelect.addEventListener("change", () => {
        contenedorEstudiantes.style.display = rolSelect.value === "padre" ? "block" : "none";
    });

    btnAgregarEstudiante?.addEventListener("click", () => {
        const div = document.createElement("div");
        div.classList.add("border", "rounded", "p-3", "mb-2");
        div.innerHTML = `
            <div class='mb-2'>
                <label class='form-label'>Nombre del Estudiante:</label>
                <input type='text' class='form-control nombreEstudiante'>
            </div>
            <div class='mb-2'>
                <label class='form-label'>Curso:</label>
                <input type='text' class='form-control cursoEstudiante'>
            </div>
            <div class='mb-2'>
                <label class='form-label'>Periodo:</label>
                <input type='text' class='form-control periodoEstudiante' value='2025-2026'>
            </div>
        `;
        listaEstudiantes.appendChild(div);
    });
});