document.addEventListener("DOMContentLoaded", () => {
    const forgotPasswordLink = document.getElementById("forgot-password");
    const modal = document.getElementById("forgot-password-modal");
    const closeModal = document.querySelector(".close");
    const sendEmailButton = document.getElementById("send-recovery-email");
    const loginBtn = document.getElementById("login-button");


    // 👉 Mostrar modal de recuperación
    if (forgotPasswordLink) {
        forgotPasswordLink.addEventListener("click", (e) => {
            e.preventDefault();
            modal.style.display = "flex";
        });
    }


    // 👉 Cerrar modal
    if (closeModal) {
        closeModal.addEventListener("click", () => {
            modal.style.display = "none";
        });
    }


    // 👉 Cerrar modal al hacer clic fuera
    window.addEventListener("click", (e) => {
        if (e.target === modal) {
            modal.style.display = "none";
        }
    });


    // 👉 Simulación de envío de email
    if (sendEmailButton) {
        sendEmailButton.addEventListener("click", async () => {
            const email = document.getElementById("recovery-email").value;
            if (email) {
                const response = await fetch("http://localhost:3000/send-recovery-email", {
                    method: "POST",
                    headers: { "Content-Type": "application/json" },
                    body: JSON.stringify({ email }),
                });


                const result = await response.json();
                alert(result.message || "Correo de recuperación enviado.");
                modal.style.display = "none";
            } else {
                alert("Por favor, ingresa un correo válido.");
            }
        });
    }


    // ✅ LOGIN
    if (loginBtn) {
        loginBtn.addEventListener("click", async (e) => {
            e.preventDefault();


            const correo = document.getElementById("login-email").value;
            const contrasena = document.getElementById("login-password").value;


            if (!correo || !contrasena) {
                return alert("Por favor ingresa tu correo y contraseña.");
            }


            try {
                const response = await fetch("http://localhost:3000/api/usuarios/login", {
                    method: "POST",
                    headers: {
                        "Content-Type": "application/json"
                    },
                    body: JSON.stringify({ correo, contrasena })
                });


                const data = await response.json();

                if (response.ok) {
                    alert(`Bienvenido, ${data.usuario.nombre}`);
                    localStorage.setItem("user", JSON.stringify(data.usuario));

                    // Redireccionar por rol
                    switch (data.usuario.rol) {
                        case "padre":
                            window.location.href = "../dashboard/IndexPadre.html";
                            break;
                        case "secretaria":
                            window.location.href = "../dashboard/indexSecretaria.html";
                            break;
                        case "directora":
                            window.location.href = "../dashboard/indexDirectora.html";
                            break;
                        default:
                            alert("Rol desconocido");
                    }
                } else {
                    alert(data.mensaje || "Credenciales incorrectas.");
                }
            } catch (error) {
                console.error("❌ Error al iniciar sesión:", error);
                alert("Ocurrió un error al iniciar sesión.");
            }
        });
    }
});