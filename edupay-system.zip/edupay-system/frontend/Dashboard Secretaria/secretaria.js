console.log("secretaria.js cargado");

document.addEventListener('DOMContentLoaded', async function () {
    const logoutButton = document.getElementById('topbar-logout-btn');
    const usernameDisplay = document.getElementById('username');
    const user = JSON.parse(localStorage.getItem("user"));
    if (user?.nombre) usernameDisplay.textContent = user.nombre;
  
    logoutButton?.addEventListener('click', () => {
      localStorage.clear();
      window.location.href = '../Login/index.html';
    });
  
    const tableBody = document.querySelector('#paymentsTable tbody');
    const paymentDetailsModal = document.querySelector('#paymentDetailsModal');
    const paymentDetailsContent = document.querySelector('#paymentDetailsContent');
    const closePaymentDetails = document.getElementById('closePaymentDetails');
  
    let allPayments = [];
  
    async function cargarPagos() {
      try {
        const res = await fetch("http://localhost:3000/api/pagos");
        const data = await res.json();
        allPayments = data;
        renderTable(allPayments);
      } catch (error) {
        console.error("Error al cargar pagos:", error);
        tableBody.innerHTML = '<tr><td colspan="7">Error al cargar los pagos.</td></tr>';
      }
    }
  
    function renderTable(pagos) {
      tableBody.innerHTML = '';
      if (!pagos.length) {
        tableBody.innerHTML = '<tr><td colspan="7">No hay pagos registrados.</td></tr>';
        return;
      }
  
      pagos.forEach(pago => {
        const row = document.createElement('tr');
        row.innerHTML = `
          <td>${pago.estudiante}</td>
          <td>${pago.padre}</td>
          <td>${new Date(pago.fecha).toLocaleDateString()}</td>
          <td>$${parseFloat(pago.monto).toFixed(2)}</td>
          <td>${pago.metodo}</td>
          <td>${pago.estado}</td>
          <td>
            <button class="view-details" data-id="${pago._id}">Ver más</button>
            ${pago.estado === 'pendiente' ? `
              <button class="approve-btn" data-id="${pago._id}">Aprobar</button>
              <button class="reject-btn" data-id="${pago._id}">Rechazar</button>
            ` : ''}
          </td>
        `;
        tableBody.appendChild(row);
      });
    }
  
    tableBody.addEventListener('click', async function (e) {
      const id = e.target.dataset.id;
  
      if (e.target.classList.contains('view-details')) {
        const pago = allPayments.find(p => p._id === id);
        if (pago) {
          paymentDetailsContent.innerHTML = `
            <p><strong>Estudiante:</strong> ${pago.estudiante}</p>
            <p><strong>Padre/Madre:</strong> ${pago.padre}</p>
            <p><strong>Fecha:</strong> ${new Date(pago.fecha).toLocaleDateString()}</p>
            <p><strong>Monto:</strong> $${parseFloat(pago.monto).toFixed(2)}</p>
            <p><strong>Método:</strong> ${pago.metodo}</p>
            <p><strong>Estado:</strong> ${pago.estado}</p>
            ${pago.boucherBase64 ? <p><strong>Boucher:</strong><img src="${pago.boucherBase64}" style="max-width:100%; border:1px solid #ccc;" /></p> : ''}
          `;
          paymentDetailsModal.style.display = 'block';
        }
      }
  
      if (e.target.classList.contains('approve-btn')) {
        if (confirm("¿Seguro que deseas aprobar este pago?")) {
          try {
            const res = await fetch(`http://localhost:3000/api/pagos/aprobar/${id}`, {
              method: 'PUT'
            });
            if (res.ok) {
              alert("Pago aprobado correctamente.");
              await cargarPagos();
            } else {
              alert("Error al aprobar el pago.");
            }
          } catch (error) {
            console.error("Error al aprobar pago:", error);
          }
        }
      }
  
      if (e.target.classList.contains('reject-btn')) {
        if (confirm("¿Seguro que deseas rechazar este pago?")) {
          try {
            const res = await fetch(`http://localhost:3000/api/pagos/rechazar/${id}`, {
              method: 'PUT'
            });
            if (res.ok) {
              alert("Pago rechazado correctamente.");
              await cargarPagos();
            } else {
              alert("Error al rechazar el pago.");
            }
          } catch (error) {
            console.error("Error al rechazar pago:", error);
          }
        }
      }
    });
  
    closePaymentDetails?.addEventListener('click', () => {
      paymentDetailsModal.style.display = 'none';
    });
  
    await cargarPagos();
  });
  
  