const Pendiente = require('../models/pendienteModel');
const express = require('express');
const router = express.Router();
const { obtenerPendientesPorPadre } = require("c:/Users/danie/OneDrive/Documents/edupay-system/edupay-backend/Controllers/pendienteController");

router.get('/:correo', obtenerPendientesPorPadre);

module.exports = router;