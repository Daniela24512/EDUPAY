// routes/pagoRoutes.js
const express = require('express');
const router = express.Router();
const {
  obtenerPagos,
  generarPDF,
  generarExcel,
  subirPagoTransferencia,
  aprobarPago,
  obtenerPagosPorPadre
} = require('../controllers/pagoController');

// Rutas accesibles según el rol

// 👉 Ver todos los pagos (secretaria y directora)
router.get('/', obtenerPagos);

// 👉 Reportes (solo secretaria)
router.post('/reporte/pdf', generarPDF);
router.post('/reporte/excel', generarExcel);

// 👉 Subida de pago por transferencia (padre)
router.post('/transferencia', subirPagoTransferencia);

// 👉 Ver pagos por padre (padre)
router.get('/padre/:correo', obtenerPagosPorPadre);

// 👉 Aprobar pago (secretaria)
router.put('/aprobar/:id', aprobarPago);

router.get('/', obtenerPagos);

module.exports = router;