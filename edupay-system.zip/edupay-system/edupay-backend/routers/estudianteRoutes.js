const express = require('express');
const router = express.Router();
const {
    crearEstudiante,
    obtenerEstudiantesPorPadre
} = require('../controllers/estudianteController');

router.post('/', crearEstudiante);
router.get('/:correo', obtenerEstudiantesPorPadre);

module.exports = router;