const express = require('express');
const router = express.Router();

const { obtenerUsuarios, crearUsuario, loginUsuario } = require('../controllers/usuarioController');

// Rutas
router.get('/', obtenerUsuarios);
//router.post('/crear', crearUsuario);
router.post('/login', loginUsuario);
router.get('/listar', obtenerUsuarios); // opcional, puedes quitar si no la usas
router.post('/', crearUsuario); // POST /api/usuarios
module.exports = router;
