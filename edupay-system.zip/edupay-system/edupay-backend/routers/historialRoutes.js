const express = require("express");
const router = express.Router();
const { obtenerHistorial } = require("../controllers/historialController");

router.get("/:correo", obtenerHistorial);

module.exports = router;