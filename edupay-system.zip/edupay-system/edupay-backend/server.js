const express = require('express');
const cors = require('cors');
require('dotenv').config();
const conectarDB = require('./config/db');
const mongoose = require('mongoose');
const app = express();

// 👇👇 ESTO ES MUY IMPORTANTE
app.use(cors());
app.use(express.json()); // <=== ¡¡ESTO!!

const usuarioRoutes = require('./routers/usuarioRoutes');
const pendienteRoutes = require('./routers/pendienteRoutes');
const historialRoutes = require('./routers/historialRoutes');
const pagoRoutes = require('./routers/pagoRoutes');
const estudianteRoutes = require('./routers/estudianteRoutes');
const path = require('path');


// RUTAS
app.use('/api/usuarios', usuarioRoutes);
app.use('/api/pendientes', pendienteRoutes);
app.use('/api/historial', historialRoutes);
app.use('/api/pagos', pagoRoutes);
app.use('/api/estudiantes', estudianteRoutes);
app.use('/Dashboard Secretaria', express.static(path.join(__dirname, '../frontend/Dashboard Secretaria/verPagos.html')));
conectarDB();

// Ruta raíz
app.get('/', (req, res) => {
  res.send('Edupay Backend is running ✅');
});

// INICIAR SERVIDOR
const PORT = process.env.PORT || 3000;
app.listen(PORT, () => {
  console.log(`Servidor corriendo en http://localhost:${PORT}`);
});
app.get('/api/test-db', async (req, res) => {
  try {
    const colecciones = await mongoose.connection.db.listCollections().toArray();
    const nombres = colecciones.map(c => c.name);
    res.json({ mensaje: 'Conectado correctamente', colecciones: nombres });
  } catch (error) {
    res.status(500).json({ mensaje: 'Error de conexión', error });
  }
});