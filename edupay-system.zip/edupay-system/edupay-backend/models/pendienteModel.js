const mongoose = require('mongoose');

const pendienteSchema = new mongoose.Schema({
    descripcion: String,
    periodo: String,
    fechaVencimiento: Date,
    estudiante: String,
    curso: String,
    monto: Number,
    correoPadre: String
}, { collection: 'pendientes' });

module.exports = mongoose.model('pendientes', pendienteSchema);