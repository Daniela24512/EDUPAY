const mongoose = require('mongoose');

const usuarioSchema = new mongoose.Schema({
    nombre: String,
    correo: String,
    contrasena: String,
    rol: {
        type: String,
        enum: ['padre', 'secretaria', 'directora']
    },
    estado: {
        type: String,
        enum: ['activo', 'inactivo'],
        default: 'activo'
    }
});

module.exports = mongoose.model('Usuario', usuarioSchema);

