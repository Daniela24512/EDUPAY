const mongoose = require('mongoose');

const estudianteSchema = new mongoose.Schema({
    nombre: { type: String, required: true },
    curso: { type: String, required: true },
    periodo: { type: String, required: true },
    correoPadre: { type: String, required: true },
    estado: { type: String, default: "activo" }
});

module.exports = mongoose.model('Estudiante', estudianteSchema);
