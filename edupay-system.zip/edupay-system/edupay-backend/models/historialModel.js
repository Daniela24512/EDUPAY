// models/historialModel.js
const mongoose = require('mongoose');

const historialSchema = new mongoose.Schema({
    descripcion: String,
    periodo: String,
    fechaPago: Date,
    estudiante: String,
    curso: String,
    monto: String,
    metodoPago: String,
    correoPadre: String,
}, { collection: 'HISTORIAL' });

module.exports = mongoose.model('HISTORIAL', historialSchema);
