// models/Pago.js
const mongoose = require('mongoose');

const pagoSchema = new mongoose.Schema({
  estudiante: String,
  padre: String,
  fecha: Date,
  monto: Number,
  metodo: String, // "transferencia"
  estado: {
    type: String,
    enum: ['pendiente', 'aprobado', 'rechazado'],
    default: 'pendiente'
  },
  boucherBase64: String //  imagen del boucher en base64
}, { collection: 'pagos' }); // <--- cambiamos a una colección "pagos"

module.exports = mongoose.model('Pago', pagoSchema);

