
const nodemailer = require('nodemailer');
require('dotenv').config();

const transporter = nodemailer.createTransport({
  service: 'gmail',
  auth: {
    user: process.env.EMAIL_USER,
    pass: process.env.EMAIL_PASS
  }
});

async function enviarCredenciales({ correo, contrasena, nombre, rol }) {
  try {
    const info = await transporter.sendMail({
      from: `"Edupay System" <${process.env.EMAIL_USER}>`,
      to: correo,
      subject: "Bienvenido a Edupay",
      html: `
        <h3>Hola ${nombre},</h3>
        <p>Tu cuenta ha sido creada exitosamente en <strong>Edupay</strong>.</p>
        <p><strong>Correo:</strong> ${correo}</p>
        <p><strong>Contraseña:</strong> ${contrasena}</p>
        <p><strong>Rol asignado:</strong> ${rol}</p>
        <br>
        <p>Por favor inicia sesión en el sistema.</p>
      `
    });

    console.log("✅ Correo enviado a:", correo);
  } catch (error) {
    console.error("❌ Error al enviar correo:", error);
  }
}

module.exports = { enviarCredenciales };
