const Estudiante = require('../models/estudianteModel');

const crearEstudiante = async (req, res) => {
    try {
        const { nombre, curso, periodo, correoPadre } = req.body;

        const nuevoEstudiante = new Estudiante({ nombre, curso, periodo, correoPadre });
        await nuevoEstudiante.save();

        res.status(201).json({ mensaje: 'Estudiante creado correctamente', estudiante: nuevoEstudiante });
    } catch (error) {
        console.error("Error al crear estudiante:", error);
        res.status(500).json({ mensaje: 'Error al crear estudiante' });
    }
};

const obtenerEstudiantesPorPadre = async (req, res) => {
    try {
        const correo = req.params.correo;
        const estudiantes = await Estudiante.find({ correoPadre: correo });
        res.status(200).json(estudiantes);
    } catch (error) {
        console.error("Error al buscar estudiantes:", error);
        res.status(500).json({ mensaje: 'Error al buscar estudiantes' });
    }
};

module.exports = {
    crearEstudiante,
    obtenerEstudiantesPorPadre
};