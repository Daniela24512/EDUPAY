const { enviarCredenciales } = require('../utils/emailService');
const Usuario = require('../models/usuarioModel');

// Obtener todos los usuarios
const obtenerUsuarios = async (req, res) => {
    try {
        const usuarios = await Usuario.find();
        res.status(200).json(usuarios);
    } catch (error) {
        res.status(500).json({ mensaje: 'Error al obtener los usuarios' });
    }
};

// Crear un nuevo usuario
const crearUsuario = async (req, res) => {
    try {
        const { nombre, correo, contrasena, rol } = req.body;

        const existe = await Usuario.findOne({ correo });
        if (existe) {
            return res.status(400).json({ mensaje: 'Este correo ya está registrado' });
        }

        const nuevoUsuario = new Usuario({ nombre, correo, contrasena, rol, estado: 'activo' });
        await nuevoUsuario.save();
        await enviarCredenciales({
            correo,
            contrasena,
            nombre,
            rol
          });

        res.status(201).json({ mensaje: 'Usuario creado correctamente', usuario: nuevoUsuario });
    } catch (error) {
        console.error('Error al crear usuario:', error);
        res.status(500).json({ mensaje: 'Error al crear usuario' });
    }
};

// Login de usuario
const loginUsuario = async (req, res) => {
    try {
        const { correo, contrasena } = req.body;
        const usuario = await Usuario.findOne({ correo });

        if (!usuario) {
            return res.status(404).json({ mensaje: 'Usuario no encontrado' });
        }

        if (usuario.contrasena !== contrasena) {
            return res.status(401).json({ mensaje: 'Contraseña incorrecta' });
        }

        res.status(200).json({
            mensaje: 'Login exitoso',
            usuario: {
                id: usuario._id,
                nombre: usuario.nombre,
                rol: usuario.rol
            }
        });
    } catch (error) {
        res.status(500).json({ mensaje: 'Error al iniciar sesión' });
    }
};

// ✅ Exportar funciones
module.exports = {
    obtenerUsuarios,
    crearUsuario,
    loginUsuario
};