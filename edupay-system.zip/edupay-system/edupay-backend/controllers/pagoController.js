// controllers/pagoController.js
const Pago = require('../models/Pago');

// Obtener todos los pagos (para secretaria y directora)
const obtenerPagos = async (req, res) => {
  try {
    const pagos = await Pago.find();
    res.status(200).json(pagos);
  } catch (error) {
    console.error("Error al obtener pagos:", error);
    res.status(500).json({ mensaje: "Error al obtener pagos" });
  }
};

// Subir pago por transferencia (para padres)
const subirPagoTransferencia = async (req, res) => {
  try {
    const { estudiante, padre, fecha, monto, boucherBase64 } = req.body;

    const nuevoPago = new Pago({
      estudiante,
      padre,
      fecha,
      monto,
      metodo: 'transferencia',
      estado: 'pendiente',
      boucherBase64
    });

    await nuevoPago.save();
    res.status(201).json({ mensaje: 'Pago enviado y en espera de aprobación', pago: nuevoPago });
  } catch (error) {
    console.error("💥 Error al subir pago:", error);
    res.status(500).json({ mensaje: 'Error al subir pago' });
  }
};

// Ver pagos enviados por un padre específico
const obtenerPagosPorPadre = async (req, res) => {
  try {
    const { correo } = req.params;
    const pagos = await Pago.find({ padre: correo });
    res.status(200).json(pagos);
  } catch (error) {
    console.error("Error al obtener pagos del padre:", error);
    res.status(500).json({ mensaje: "Error al obtener pagos del padre" });
  }
};

// Aprobar pago manualmente (por secretaria)
const aprobarPago = async (req, res) => {
  try {
    const { id } = req.params;

    const pago = await Pago.findById(id);
    if (!pago) return res.status(404).json({ mensaje: 'Pago no encontrado' });

    pago.estado = 'aprobado';
    await pago.save();

    res.status(200).json({ mensaje: 'Pago aprobado correctamente', pago });
  } catch (error) {
    console.error("💥 Error al aprobar pago:", error);
    res.status(500).json({ mensaje: 'Error al aprobar pago' });
  }
};

// PUT /api/pagos/rechazar/:id
const rechazarPago = async (req, res) => {
  try {
      const pago = await Pago.findByIdAndUpdate(req.params.id, { estado: 'rechazado' }, { new: true });
      if (!pago) return res.status(404).json({ mensaje: 'Pago no encontrado' });
      res.status(200).json(pago);
  } catch (err) {
      res.status(500).json({ mensaje: 'Error al rechazar pago' });
  }
};

// Generar reporte en PDF (para secretaria)
const generarPDF = (req, res) => {
  res.send("Generando PDF...");
};

// Generar reporte en Excel (para secretaria)
const generarExcel = (req, res) => {
  res.send("Generando Excel...");
};

module.exports = {
  obtenerPagos,
  generarPDF,
  generarExcel,
  subirPagoTransferencia,
  aprobarPago,
  obtenerPagosPorPadre
};