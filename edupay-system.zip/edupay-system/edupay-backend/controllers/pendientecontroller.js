const Pendiente = require('../models/pendienteModel');

const obtenerPendientesPorPadre = async (req, res) => {
    try {
        const { correo } = req.params;
        console.log("📩 Correo recibido:", correo);
        const pendientes = await Pendiente.find({ correoPadre: correo });
        res.status(200).json(pendientes);
    } catch (error) {
        console.error("Error al obtener pendientes:", error);
        res.status(500).json({ mensaje: 'Error al obtener pagos pendientes' });
    }
};

module.exports = {
    obtenerPendientesPorPadre
};
