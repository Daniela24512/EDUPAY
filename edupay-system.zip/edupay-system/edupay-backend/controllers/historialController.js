const Historial = require("../models/historialModel");

const obtenerHistorial = async (req, res) => {
    try {
        const { correo } = req.params;
        console.log("📩 Correo recibido:", correo);

        const historial = await Historial.find({ correoPadre: correo });
        res.status(200).json(historial);
    } catch (error) {
        console.error("Error al obtener historial:", error);
        res.status(500).json({ mensaje: "Error al obtener historial" });
    }
};

module.exports = {
    obtenerHistorial
};